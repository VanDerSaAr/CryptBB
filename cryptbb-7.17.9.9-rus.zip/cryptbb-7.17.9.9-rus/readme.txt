﻿/*=============================================================================================

Application: CryptBB
Version: 7.17.9.9

Author: VanDerSaAr
Signature: RSA-2048

This PHP+JS application, the encrypted forum with open source code, provides a more secure private communication between people. All messages are transmited over internet and are stored in the database in the encrypted format. All mathematical cryptographic operations are executed by client (internet browser), not by server. To encrypt the messages, this forum uses AES (Rijndael) 256 CTR (Counter mode), the symmetric military-class encryption (USA) 2012, and to exchange the password between users - RSA (Rivest-Shamir-Adleman) 768-2048, one of the best asymmetric ciphers at present time (2012). With this application You can create Your own forums and discuss with Your friends any topics securely. Anybody (even administrator) cannot read Your closed messages. Join the encrypted community!

Site: http://cryptbb.us.to

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

License: MIT
Link: http://www.opensource.org/licenses/mit-license.html

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
 
-----------------------------------------------------------------------------------------------

How to install:
1) Upload cryptbb.zip to Your host
2) Unpack cryptbb.zip in Your host
3) Open /index.php with Your browser
4) Follow further instructions

*///===========================================================================================