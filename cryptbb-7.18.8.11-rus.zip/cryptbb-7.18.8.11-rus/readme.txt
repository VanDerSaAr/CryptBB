﻿/*=============================================================================================

Application: CryptBB
Version: 7.18.8.11

Author: VanDerSaAr
Signature: RSA-2048

This application, the encrypted forum with the open source code, provides a more secure private communication between the people. All messages are transmitted over the internet and are stored in the database in the encrypted format. All the mathematical cryptographic operations are executed by the client (internet browser), not by the server. This forum uses the symmetric military-class encryption AES (Rijndael) 256 CTR (Counter mode) for encrypting the messages and one of the best asymmetric ciphers RSA (Rivest-Shamir-Adleman) 768-2048 OAEP for exchanging the passwords between the members. Here You can create Your own forums and discuss with Your friends any topics securely. Anybody (even administrator) cannot read Your closed messages. Join the encrypted community!

Site: http://cryptbb.us.to

~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

License: MIT
Link: http://www.opensource.org/licenses/mit-license.html

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
 
-----------------------------------------------------------------------------------------------

How to install:
1) Upload the file cryptbb.zip to Your host (with installed PHP+MySQL)
2) Unpack the file cryptbb.zip at Your host
3) Open the link http://<YOUR_HOST>/index.php in Your browser
4) Follow the further instructions

*///===========================================================================================